package com.ssafy.enjoytrip.util;

public class SizeConstant {

	public final static int LIST_SIZE = 20; // 한 페이지당 글 갯수
	public final static int NAVIGATION_SIZE = 5; // 네비게이션 범위
	
}
