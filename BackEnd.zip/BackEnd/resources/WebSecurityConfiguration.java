//package com.ssafy.enjoytrip.config;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer.JwtConfigurer;
//
//@Configuration
//@EnableWebSecurity
//public class WebSecurityConfiguration {
//	
//	private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfiguration.class);
//	
//	private final JwtConfigurer jwtConfigurer;
//	
//	public WebSecurityConfiguration(JwtConfigurer jwtConfigurer) {
//		this.jwtConfigurer = jwtConfigurer;
//	}
//}
